import { expect, test } from '@playwright/test';

test('ouvre l’administration locale', async ({ page }) => {
  await page.setViewportSize({ width: 1366, height: 768 });
  await page.goto('/admin');
  await expect(page.getByRole('heading', { name: 'Tafaron' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Créer la partie' })).toBeVisible();
  await page.screenshot({ path: 'test-results/admin-home.png', fullPage: true });
});

test('affiche, filtre et ouvre les statistiques joueurs', async ({ page }) => {
  await page.route('**/api/stats/players?**', async (route) => route.fulfill({ json: [{ profileId: 'alice', displayName: 'Alice', aliases: ['alice'], active: true, gamesPlayed: 4, wins: 2, winRate: 50, podiums: 3, podiumRate: 75, averagePlacement: 1.75, averageScore: 12.5, bestScore: -20, worstScore: 50 }] }));
  await page.route('**/api/admin/session', async (route) => route.fulfill({ json: { token: 'test' } }));
  await page.route('**/api/stats/identity', async (route) => route.fulfill({ json: { profiles: [], appearances: [] } }));
  await page.goto('/stats');
  await expect(page.getByRole('heading', { name: 'Statistiques des joueurs' })).toBeVisible();
  await expect(page.getByRole('link', { name: 'Alice' })).toBeVisible();
  await page.getByLabel('Rechercher un joueur').fill('absent');
  await expect(page.getByText(/Aucun joueur/)).toBeVisible();
});

test('affiche le profil, les tendances et les contrats à largeur étroite', async ({ page }) => {
  await page.setViewportSize({ width: 520, height: 900 });
  await page.route('**/api/stats/players/alice?**', async (route) => route.fulfill({ json: {
    summary: { profileId: 'alice', displayName: 'Alice', aliases: ['alice'], active: true, gamesPlayed: 1, wins: 1, winRate: 100, podiums: 1, podiumRate: 100, averagePlacement: 1, averageScore: -25, bestScore: -25, worstScore: -25 },
    games: [{ gameId: 'g1', gameName: 'Soirée', completedAt: '2026-01-02T20:00:00Z', sourcePlayerId: 'p1', sourceName: 'Alice', placement: 1, finalScore: -25, playerCount: 3, participants: ['Alice', 'Bob', 'Cara'], enabledContracts: ['J'], scoring: { successFirst: -100, successSecond: -50, heart: 20, queen: 50, kingOfHearts: 100, trick: 40, lastTrick: 100, bonus: -25 } }],
    contracts: [{ contract: 'J', chooser: { rounds: 1, successes: 1, successRate: 100, bonuses: 1, totalDelta: -25, averageDelta: -25 }, allRound: { rounds: 1, successes: 0, successRate: 0, bonuses: 0, totalDelta: -25, averageDelta: -25 }, jokerBreakdown: { C: { rounds: 1, chooserRounds: 1, totalDelta: -25 } } }],
  } }));
  await page.goto('/stats/players/alice');
  await expect(page.getByRole('heading', { name: 'Alice' })).toBeVisible();
  await expect(page.getByText('Détail du Joker')).toBeVisible();
  await page.getByRole('button', { name: 'Score' }).click();
  await expect(page.getByRole('heading', { name: 'Score final' })).toBeVisible();
});
